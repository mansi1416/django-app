import pandas as pd
import numpy as np
from typing import Tuple, Optional
import traceback

def load_data(uploaded_file) -> Optional[pd.DataFrame]:
    """Load data from uploaded file."""
    try:
        print(f"Loading file: {uploaded_file.filename}")  # Debug log
        if uploaded_file.filename.endswith('.csv'):
            return pd.read_csv(uploaded_file)
        elif uploaded_file.filename.endswith(('.xls', '.xlsx')):
            return pd.read_excel(uploaded_file)
        else:
            print(f"Unsupported file format: {uploaded_file.filename}")
            return None
    except Exception as e:
        print(f"Error loading file: {str(e)}")
        print(traceback.format_exc())
        return None

def get_summary_statistics(df: pd.DataFrame) -> pd.DataFrame:
    """Generate summary statistics for numerical columns."""
    try:
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        if len(numeric_cols) == 0:
            return pd.DataFrame()
        summary = df[numeric_cols].describe()
        return summary
    except Exception as e:
        print(f"Error generating summary statistics: {str(e)}")
        return pd.DataFrame()

def filter_dataframe(df: pd.DataFrame, column: str, filter_value: str) -> pd.DataFrame:
    """Filter dataframe based on column value."""
    try:
        if pd.api.types.is_numeric_dtype(df[column]):
            try:
                filter_value = float(filter_value)
                return df[df[column] == filter_value]
            except ValueError:
                return df
        return df[df[column].astype(str).str.contains(filter_value, case=False)]
    except Exception as e:
        print(f"Error filtering dataframe: {str(e)}")
        return df

def get_column_types(df: pd.DataFrame) -> Tuple[list, list]:
    """Get numerical and categorical columns from dataframe."""
    try:
        numerical_cols = df.select_dtypes(include=[np.number]).columns.tolist()
        categorical_cols = df.select_dtypes(exclude=[np.number]).columns.tolist()
        return numerical_cols, categorical_cols
    except Exception as e:
        print(f"Error getting column types: {str(e)}")
        return [], []