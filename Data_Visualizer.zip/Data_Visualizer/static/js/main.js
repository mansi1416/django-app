let currentData = null;

document.getElementById('fileInput').addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (!file) return;

    console.log('Uploading file:', file.name);
    const formData = new FormData();
    formData.append('file', file);

    fetch('/upload', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            console.error('Upload error:', data.error);
            alert(data.error);
            return;
        }

        console.log('Data loaded successfully');
        currentData = data;
        document.getElementById('dataInfo').classList.remove('hidden');

        // Populate column selectors
        const xSelect = document.getElementById('xColumn');
        const ySelect = document.getElementById('yColumn');

        xSelect.innerHTML = '';
        ySelect.innerHTML = '';

        data.columns.forEach(col => {
            xSelect.add(new Option(col, col));
        });

        data.numerical_columns.forEach(col => {
            ySelect.add(new Option(col, col));
        });

        // Display preview
        displayPreview(data.preview);

        // Display summary statistics
        displaySummary(data.summary);
    })
    .catch(error => {
        console.error('Upload error:', error);
        alert('Error uploading file: ' + error.message);
    });
});

function displayPreview(preview) {
    const container = document.getElementById('previewTable');
    if (!preview || preview.length === 0) {
        container.innerHTML = 'No preview data available';
        return;
    }

    const table = document.createElement('table');

    // Create header
    const header = document.createElement('tr');
    Object.keys(preview[0]).forEach(key => {
        const th = document.createElement('th');
        th.textContent = key;
        header.appendChild(th);
    });
    table.appendChild(header);

    // Create rows
    preview.forEach(row => {
        const tr = document.createElement('tr');
        Object.values(row).forEach(value => {
            const td = document.createElement('td');
            td.textContent = value;
            tr.appendChild(td);
        });
        table.appendChild(tr);
    });

    container.innerHTML = '';
    container.appendChild(table);
}

function displaySummary(summary) {
    const container = document.getElementById('summaryStats');
    if (!summary) {
        container.innerHTML = 'No summary statistics available';
        return;
    }

    const table = document.createElement('table');

    // Create header
    const header = document.createElement('tr');
    const th = document.createElement('th');
    th.textContent = 'Statistic';
    header.appendChild(th);
    Object.keys(summary).forEach(key => {
        const th = document.createElement('th');
        th.textContent = key;
        header.appendChild(th);
    });
    table.appendChild(header);

    // Create rows
    const stats = ['count', 'mean', 'std', 'min', '25%', '50%', '75%', 'max'];
    stats.forEach(stat => {
        const tr = document.createElement('tr');
        const td = document.createElement('td');
        td.textContent = stat;
        tr.appendChild(td);

        Object.values(summary).forEach(col => {
            const td = document.createElement('td');
            td.textContent = col[stat]?.toFixed(2) || 'N/A';
            tr.appendChild(td);
        });
        table.appendChild(tr);
    });

    container.innerHTML = '';
    container.appendChild(table);
}

function createVisualization() {
    const chartType = document.getElementById('chartType').value;
    const xColumn = document.getElementById('xColumn').value;
    const yColumn = document.getElementById('yColumn').value;
    const title = document.getElementById('chartTitle').value || 'Visualization';

    if (!currentData || !currentData.preview) {
        alert('Please upload data first');
        return;
    }

    // For histogram, we don't need y-column
    if (chartType !== 'histogram' && !yColumn) {
        alert('Please select Y-axis column');
        return;
    }

    console.log('Creating visualization:', {
        type: chartType,
        x: xColumn,
        y: yColumn,
        title: title
    });

    fetch('/visualize', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            data: currentData.preview,
            chartType: chartType,
            xColumn: xColumn,
            yColumn: yColumn,
            title: title
        })
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.json();
    })
    .then(data => {
        if (data.error) {
            console.error('Visualization error:', data.error);
            alert('Error creating visualization: ' + data.error);
            return;
        }

        console.log('Received visualization data');
        try {
            const chartData = JSON.parse(data.chart);
            console.log('Plotting chart with data:', chartData);

            const chartContainer = document.getElementById('chartContainer');
            chartContainer.innerHTML = ''; // Clear previous chart

            Plotly.newPlot('chartContainer', chartData.data, chartData.layout)
                .then(() => console.log('Chart rendered successfully'))
                .catch(err => {
                    console.error('Error rendering chart:', err);
                    alert('Error rendering visualization');
                });
        } catch (e) {
            console.error('Error parsing chart data:', e);
            alert('Error rendering visualization');
        }
    })
    .catch(error => {
        console.error('Visualization request error:', error);
        alert('Error creating visualization: ' + error.message);
    });
}

// Update Y-axis column visibility based on chart type
document.getElementById('chartType').addEventListener('change', function(e) {
    const yColumnSelect = document.getElementById('yColumn');
    const yColumnLabel = yColumnSelect.previousElementSibling;

    if (e.target.value === 'histogram') {
        yColumnSelect.style.display = 'none';
        yColumnLabel && (yColumnLabel.style.display = 'none');
    } else {
        yColumnSelect.style.display = 'block';
        yColumnLabel && (yColumnLabel.style.display = 'block');
    }
});