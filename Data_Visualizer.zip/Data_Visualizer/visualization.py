import plotly.express as px
import plotly.graph_objects as go
from typing import Optional
import pandas as pd

def create_line_chart(df: pd.DataFrame, x_col: str, y_col: str, title: str, color: str) -> go.Figure:
    """Create a line chart using plotly."""
    fig = px.line(df, x=x_col, y=y_col, title=title)
    fig.update_traces(line_color=color)
    fig.update_layout(
        xaxis_title=x_col,
        yaxis_title=y_col,
        showlegend=True
    )
    return fig

def create_bar_chart(df: pd.DataFrame, x_col: str, y_col: str, title: str, color: str) -> go.Figure:
    """Create a bar chart using plotly."""
    fig = px.bar(df, x=x_col, y=y_col, title=title)
    fig.update_traces(marker_color=color)
    fig.update_layout(
        xaxis_title=x_col,
        yaxis_title=y_col,
        showlegend=True
    )
    return fig

def create_scatter_plot(df: pd.DataFrame, x_col: str, y_col: str, title: str, color: str) -> go.Figure:
    """Create a scatter plot using plotly."""
    fig = px.scatter(df, x=x_col, y=y_col, title=title)
    fig.update_traces(marker_color=color)
    fig.update_layout(
        xaxis_title=x_col,
        yaxis_title=y_col,
        showlegend=True
    )
    return fig

def create_histogram(df: pd.DataFrame, column: str, title: str, color: str) -> go.Figure:
    """Create a histogram using plotly."""
    fig = px.histogram(df, x=column, title=title)
    fig.update_traces(marker_color=color)
    fig.update_layout(
        xaxis_title=column,
        yaxis_title="Count",
        showlegend=True
    )
    return fig
